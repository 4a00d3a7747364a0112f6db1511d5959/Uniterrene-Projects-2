A Pen created at CodePen.io. You can find this one at http://codepen.io/AnimalInstinct/pen/Dbgem.

 Simple function to show and hide div on click , or toggle div on click.